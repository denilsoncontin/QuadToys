<?php
include 'includes/header.php';

echo "<div class='container'><h1>Finalização de Compra</h1><p>Em breve aqui!</p></div>";

include 'includes/footer.php';
?>
